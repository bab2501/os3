#!/usr/bin/python
# This should start the regex test
print "Starting the regex test"
X = 5 # Initialize X to be 5
if X == 5:
  print "Working"
else:
  print "FAIL"

