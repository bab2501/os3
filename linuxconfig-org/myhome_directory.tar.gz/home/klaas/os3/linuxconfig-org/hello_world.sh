#!/bin/bash
#Author: Dhr. ing. B.A. Blaauwgeers
# C: linuxconfig.org
# T: Hallo World Bash Sell Script

# declare  STRING variable
STRING="Hello World"
#print variable on screen
echo $STRING
