#!/bin/bash
#Author: Dhr. ing. B.A. Blaauwgeers
# C: linuxconfig.org
# T: 2) Simple Backup bash shell script

tar -czf myhome_directory.tar.gz /home/klaas/os3/linuxconfig-org
