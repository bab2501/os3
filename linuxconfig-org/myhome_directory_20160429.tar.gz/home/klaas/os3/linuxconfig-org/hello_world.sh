#!/bin/bash
#Author: Dhr. ing. B.A. Blaauwgeers
# C: linuxconfig.org
# T: 1)	Hallo World Bash Sell Script
# T: 3) Variables

# declare  STRING variable
STRING="HELLO WORLD!!!"
#print variable on screen
echo $STRING
